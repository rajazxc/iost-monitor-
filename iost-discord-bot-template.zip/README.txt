IOST Discord Bot Template

Replace YOUR_DISCORD_WEBHOOK_URL in config.txt with your webhook.
This is only a template. It does not include a working IOST monitor.
A working monitor requires implementation against the IOST API and deployment.
